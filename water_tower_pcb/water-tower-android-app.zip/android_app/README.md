# 水塔任务 Android 应用

水塔任务的 Android 移动端应用。

## 📱 项目信息

- **应用名称**: 水塔任务
- **包名**: com.watertower.task
- **最低 Android 版本**: 7.0 (API 24)
- **目标 Android 版本**: 14 (API 34)

## 🚀 自动构建

本项目使用 **Gitee Go** 进行持续集成，自动构建 APK。

### 触发条件
- 推送到 `master` 分支
- 向 `master` 分支提交 Pull Request

### 构建产物
- `app/build/outputs/apk/debug/app-debug.apk`

## 📦 本地构建

```bash
# 克隆项目
git clone <your-repo-url>
cd android_app

# 授予 gradlew 执行权限
chmod +x gradlew

# 构建 Debug APK
./gradlew clean assembleDebug

# APK 输出位置
# app/build/outputs/apk/debug/app-debug.apk
```

## 📁 项目结构

```
android_app/
├── .gitee/
│   └── go.yml              # Gitee Go 持续集成配置
├── app/
│   ├── src/main/
│   │   ├── java/           # Java 源代码
│   │   ├── res/            # 资源文件
│   │   └── AndroidManifest.xml
│   └── build.gradle        # 应用级构建配置
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle            # 项目级构建配置
├── settings.gradle         # 项目设置
└── gradle.properties       # Gradle 属性
```

## 🛠 技术栈

- **语言**: Java
- **UI 框架**: AndroidX + Material Design
- **构建工具**: Gradle 8.2
- **JDK 版本**: 17

## 📄 许可证

私有项目
