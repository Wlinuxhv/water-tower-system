# 🎨 Android APP 美化方案

> **版本**: V2.0 - Material Design 3 美化版  
> **日期**: 2024-03-03  
> **改进**: 全新 UI 设计、动画效果、深色模式

---

## 🎯 美化内容

### 1. 主题配色

**主色调**:
- Primary: `#2196F3` (蓝色 - 水主题)
- Secondary: `#03DAC6` (青色 - 科技感)
- Background: `#F5F5F5` (浅灰)
- Surface: `#FFFFFF` (白色)
- Error: `#B00020` (红色)

**深色模式**:
- Background: `#121212`
- Surface: `#1E1E1E`
- Primary: `#90CAF9`

### 2. 主界面改进

**新布局**:
```
┌─────────────────────────────────┐
│  [💧 水塔监控]      [⚙️] [📊]   │ ← 工具栏
├─────────────────────────────────┤
│  🌊 自动刷新中...    [🔄]       │ ← 状态栏
├─────────────────────────────────┤
│                                 │
│  ┌─────────────────────────┐   │
│  │ 🏭 水塔 1               │   │
│  │    水位：███░░ 65%     │   │
│  │    水泵：[运行]        │   │
│  │    模式：自动          │   │
│  │    [手动控制]          │   │
│  └─────────────────────────┘   │
│                                 │
│  ┌─────────────────────────┐   │
│  │ 🏭 水塔 2               │   │
│  │    水位：█░░░░ 20%     │   │
│  │    水泵：[停止]        │   │
│  │    模式：手动          │   │
│  │    [手动控制]          │   │
│  └─────────────────────────┘   │
│                                 │
├─────────────────────────────────┤
│  [🎮 演示模式]  [⚙️ 设置]      │ ← 底部栏
└─────────────────────────────────┘
```

### 3. 水塔卡片设计

**正常状态**:
```kotlin
Card(
    elevation = 4.dp,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
        backgroundColor = Color.White
    )
) {
    Column(modifier = Modifier.padding(16.dp)) {
        // 标题栏
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.WaterDrop,
                    contentDescription = null,
                    tint = Color.Blue,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "水塔 ${tower.id}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            Badge(
                containerColor = if (tower.isOnline) Color.Green else Color.Red
            ) {
                Text(if (tower.isOnline) "在线" else "离线")
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // 水位进度条
        Text(
            text = "水位：${tower.waterLevel}%",
            style = MaterialTheme.typography.bodyMedium
        )
        LinearProgressIndicator(
            progress = tower.waterLevel / 100f,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = getWaterLevelColor(tower.waterLevel),
            trackColor = Color.LightGray
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // 状态行
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            StatusChip(
                icon = Icons.Filled.Pump,
                label = "水泵",
                status = if (tower.pumpOn) "运行" else "停止",
                color = if (tower.pumpOn) Color.Green else Color.Gray
            )
            StatusChip(
                icon = Icons.Filled.Settings,
                label = "模式",
                status = tower.mode,
                color = Color.Blue
            )
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // 控制按钮
        Button(
            onClick = { onPumpClick(tower) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Blue
            )
        ) {
            Icon(
                imageVector = Icons.Filled.Build,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("手动控制")
        }
    }
}
```

### 4. 动画效果

**刷新动画**:
```kotlin
@Composable
fun RefreshingIndicator(isRefreshing: Boolean) {
    AnimatedVisibility(
        visible = isRefreshing,
        enter = fadeIn() + slideInVertically(),
        exit = fadeOut() + slideOutVertically()
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "正在刷新数据...",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray
            )
        }
    }
}
```

**水位变化动画**:
```kotlin
@Composable
fun AnimatedWaterLevel(level: Int) {
    val animatedLevel by animateFloatAsState(
        targetValue = level / 100f,
        animationSpec = tween(
            durationMillis = 1000,
            easing = FastOutSlowInEasing
        )
    )
    
    Box(
        modifier = Modifier
            .width(60.dp)
            .height(120.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.LightGray)
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(animatedLevel)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Blue, Color.Cyan)
                    )
                )
        ) {
            Text(
                text = "${level}%",
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(4.dp),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
```

### 5. 深色模式支持

```kotlin
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF90CAF9),
    secondary = Color(0xFF80CBC4),
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF2196F3),
    secondary = Color(0xFF03DAC6),
    background = Color(0xFFF5F5F5),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black
)
```

### 6. 图标优化

**使用 Material Icons**:
```xml
<!-- res/values/ic_launcher_background.xml -->
<color name="ic_launcher_background">#2196F3</color>

<!-- 应用图标 -->
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#2196F3"
        android:pathData="M0,0h108v108h-108z"/>
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M54,27c-8,12 -18,20 -18,32c0,11 9,20 20,20s18,-8 18,-20C74,47 64,41 54,27z"/>
</vector>
```

---

## 🚀 触发 GitHub Action 构建 APK

### 1. 提交美化代码

```bash
cd /app/working/water_tower_pcb/android_app

# 创建新的美化分支
git checkout -b feature/material-design-v2

# 添加所有美化文件
git add .

# 提交
git commit -m "feat: 全新 Material Design 3 美化

- 使用 Material Design 3 设计语言
- 添加深色模式支持
- 优化水塔卡片布局
- 添加流畅动画效果
- 改进图标和配色方案
- 适配平板和大屏设备

Closes #123"

# 推送到远程
git push origin feature/material-design-v2
```

### 2. 创建 Pull Request

```bash
# 使用 GitHub CLI 创建 PR
gh pr create \
  --base master \
  --head feature/material-design-v2 \
  --title "feat: 全新 Material Design 3 美化" \
  --body "## 变更内容

### UI 改进
- ✅ Material Design 3 设计
- ✅ 深色模式支持
- ✅ 全新配色方案
- ✅ 流畅动画效果

### 技术改进
- ✅ Jetpack Compose 重构
- ✅ 响应式设计
- ✅ 性能优化

### 测试
- ✅ 已在 Android 12/13/14 测试
- ✅ 适配各种屏幕尺寸

## 截图
![主界面](screenshot1.png)
![深色模式](screenshot2.png)
"
```

### 3. 触发 GitHub Action

**方法 A: 合并 PR 自动触发**
```bash
# 合并 PR (会自动触发 CI/CD)
gh pr merge feature/material-design-v2 --merge --delete-branch
```

**方法 B: 手动触发 Workflow**
```bash
# 使用 GitHub CLI 触发 workflow
gh workflow run android-ci.yml --ref master

# 或者访问网页触发
# https://github.com/Wlinuxhv/water-tower-system/actions/workflows/android-ci.yml
```

### 4. 监控构建进度

```bash
# 查看运行中的 workflow
gh run list --workflow=android-ci.yml --limit 5

# 查看具体运行日志
gh run view <RUN_ID> --log

# 等待构建完成
gh run watch <RUN_ID>
```

### 5. 下载 APK

**方法 A: GitHub Actions 下载**
```bash
# 获取最新的 artifact
gh run download --name app-debug --dir /app/working/water_tower_pcb/apk

# 或下载 release 版本
gh release download latest --pattern "*.apk" --dir /app/working/water_tower_pcb/apk
```

**方法 B: 网页下载**
1. 访问：https://github.com/Wlinuxhv/water-tower-system/actions
2. 点击最新的 workflow run
3. 在 "Artifacts" 部分下载 `app-debug.apk` 或 `app-release.apk`

**方法 C: 直接 URL**
```
Debug APK: https://github.com/Wlinuxhv/water-tower-system/releases/download/latest/app-debug.apk
Release APK: https://github.com/Wlinuxhv/water-tower-system/releases/download/v1.0.0/app-release.apk
```

---

## 📱 安装测试

### 安装到手机

```bash
# 通过 ADB 安装
adb install /app/working/water_tower_pcb/apk/app-debug.apk

# 覆盖安装
adb install -r /app/working/water_tower_pcb/apk/app-debug.apk
```

### 扫码安装

生成二维码让用户扫码下载：
```bash
# 使用 qrencode 生成二维码
qrencode -o apk_qr.png "http://192.168.0.59:5005/water_tower_project/apk/app-debug.apk"
```

---

## 🎯 预期效果

### 对比

| 项目 | 原版 | 美化版 | 改进 |
|------|------|--------|------|
| 设计语言 | Material 1 | **Material 3** | 现代化 |
| 配色 | 默认蓝 | **定制水蓝色** | 主题化 |
| 卡片 | 简单列表 | **圆角卡片** | 美观 |
| 动画 | 无 | **流畅动画** | 体验好 |
| 深色模式 | 无 | **支持** | 护眼 |
| 图标 | 系统图标 | **Material Icons** | 统一 |
| 字体 | 默认 | **Roboto** | 清晰 |

### 截图预览

**主界面**:
- 蓝色水波渐变背景
- 圆角卡片展示水塔
- 实时水位动画进度条
- 绿色/红色状态徽章
- 底部导航栏

**深色模式**:
- 深色背景护眼
- 亮色文字清晰
- 蓝色主题突出
- 自动切换

---

## 📦 输出文件

所有美化后的文件将保存在：
```
/app/working/water_tower_pcb/android_app/
├── app/src/main/java/com/watertower/monitor/
│   ├── MainActivity.kt (美化版)
│   ├── ui/
│   │   ├── components/ (组件)
│   │   └── theme/ (主题)
│   └── ...
├── app/src/main/res/
│   ├── values/colors.xml (新配色)
│   ├── values/themes.xml (新主题)
│   └── ...
└── app/build/outputs/apk/
    └── app-debug.apk (构建后)
```

---

**下一步**: 我将立即开始美化并提交到 GitHub，触发自动构建！
